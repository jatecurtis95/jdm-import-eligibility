import { describe, expect, it } from "vitest";
import {
  getMakes,
  getModels,
  searchVehicles,
  getRegisterEntries,
  getEntryDetail,
  searchByChassis,
  getDataStats,
} from "./vehicleData";

describe("vehicleData", () => {
  describe("getMakes", () => {
    it("returns an array of makes with counts", () => {
      const makes = getMakes();
      expect(Array.isArray(makes)).toBe(true);
      expect(makes.length).toBeGreaterThan(0);

      const toyota = makes.find((m) => m.make.toLowerCase() === "toyota");
      expect(toyota).toBeDefined();
      expect(toyota!.count).toBeGreaterThan(0);
    });

    it("returns makes sorted alphabetically", () => {
      const makes = getMakes();
      for (let i = 1; i < makes.length; i++) {
        expect(makes[i].make.localeCompare(makes[i - 1].make)).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe("getModels", () => {
    it("returns models for a given make", () => {
      const models = getModels("Toyota");
      expect(Array.isArray(models)).toBe(true);
      expect(models.length).toBeGreaterThan(0);

      const alphard = models.find((m) => m.model.toLowerCase().includes("alphard"));
      expect(alphard).toBeDefined();
    });

    it("returns empty array for unknown make", () => {
      const models = getModels("NonExistentMake12345");
      expect(models).toEqual([]);
    });

    it("is case-insensitive for make", () => {
      const models1 = getModels("Toyota");
      const models2 = getModels("TOYOTA");
      const models3 = getModels("toyota");
      expect(models1.length).toBe(models2.length);
      expect(models1.length).toBe(models3.length);
    });
  });

  describe("searchVehicles", () => {
    it("returns paginated results for a make search", () => {
      const result = searchVehicles({ make: "Toyota", page: 1, pageSize: 10 });
      expect(result.results.length).toBeLessThanOrEqual(10);
      expect(result.total).toBeGreaterThan(0);
      expect(result.page).toBe(1);
      expect(result.pageSize).toBe(10);
    });

    it("filters by text query", () => {
      const result = searchVehicles({ query: "Crown" });
      expect(result.results.length).toBeGreaterThan(0);
      for (const r of result.results) {
        const combined = `${r.make} ${r.model}`.toLowerCase();
        expect(combined).toContain("crown");
      }
    });

    it("returns results with eligible flag", () => {
      const result = searchVehicles({ make: "Toyota" });
      for (const r of result.results) {
        expect(typeof r.eligible).toBe("boolean");
        expect(r.eligible).toBe(true); // All results in the register are eligible
      }
    });

    it("returns results with build date range", () => {
      const result = searchVehicles({ make: "Toyota" });
      for (const r of result.results) {
        expect(typeof r.buildDateRange).toBe("string");
        expect(r.buildDateRange.length).toBeGreaterThan(0);
      }
    });

    it("supports year filtering", () => {
      const result = searchVehicles({ make: "Toyota", yearFrom: 2020 });
      expect(result.total).toBeGreaterThan(0);
      // All results should have a build year range that includes 2020+
      for (const r of result.results) {
        if (r.buildYearEnd !== null) {
          expect(r.buildYearEnd).toBeGreaterThanOrEqual(2020);
        }
      }
    });

    it("paginates correctly", () => {
      const page1 = searchVehicles({ make: "Toyota", page: 1, pageSize: 5 });
      const page2 = searchVehicles({ make: "Toyota", page: 2, pageSize: 5 });
      expect(page1.results.length).toBe(5);
      expect(page2.results.length).toBeGreaterThan(0);
      // Results should be different
      expect(page1.results[0].id).not.toBe(page2.results[0].id);
    });
  });

  describe("getRegisterEntries", () => {
    it("returns entries for a known vehicle", () => {
      const entries = getRegisterEntries("Toyota", "Alphard");
      expect(entries.length).toBeGreaterThan(0);
    });

    it("returns entries with correct types", () => {
      const entries = getRegisterEntries("Toyota", "Alphard");
      for (const entry of entries) {
        expect(["MRE", "SEV"]).toContain(entry.type);
        expect(entry.make).toBe("Toyota");
        expect(entry.model).toBe("Alphard");
        expect(typeof entry.buildDateRange).toBe("string");
        expect(typeof entry.statusLabel).toBe("string");
      }
    });

    it("returns empty array for unknown vehicle", () => {
      const entries = getRegisterEntries("NonExistent", "Vehicle");
      expect(entries).toEqual([]);
    });
  });

  describe("getEntryDetail", () => {
    it("returns detail for a known MRE code", () => {
      const detail = getEntryDetail("MRE-000014");
      expect(detail).not.toBeNull();
      expect(detail!.type).toBe("MRE");
      expect(detail!.code).toBe("MRE-000014");
      expect(detail!.make).toBe("Toyota");
    });

    it("returns null for unknown code", () => {
      const detail = getEntryDetail("NONEXISTENT-999999");
      expect(detail).toBeNull();
    });

    it("returns detail for a known SEV code", () => {
      // Get a known SEV code from the data
      const entries = getRegisterEntries("Toyota", "Alphard");
      const sevEntry = entries.find((e) => e.type === "SEV");
      if (sevEntry) {
        const detail = getEntryDetail(sevEntry.code);
        expect(detail).not.toBeNull();
        expect(detail!.type).toBe("SEV");
      }
    });
  });

  describe("searchByChassis", () => {
    it("returns results for a known chassis code", () => {
      const results = searchByChassis("JZX100");
      expect(results.length).toBeGreaterThan(0);
      for (const r of results) {
        const hasChassis = r.chassisCodes.some((c) => c.toUpperCase().includes("JZX100"));
        expect(hasChassis).toBe(true);
      }
    });

    it("returns empty for very short query", () => {
      const results = searchByChassis("A");
      expect(results).toEqual([]);
    });

    it("is case-insensitive", () => {
      const upper = searchByChassis("JZX100");
      const lower = searchByChassis("jzx100");
      expect(upper.length).toBe(lower.length);
    });
  });

  describe("getDataStats", () => {
    it("returns stats with correct shape", () => {
      const stats = getDataStats();
      expect(typeof stats.fetchedAt).toBe("string");
      expect(typeof stats.mreCount).toBe("number");
      expect(typeof stats.sevCount).toBe("number");
      expect(typeof stats.totalMakes).toBe("number");
      expect(stats.mreCount).toBeGreaterThan(0);
      expect(stats.sevCount).toBeGreaterThan(0);
      expect(stats.totalMakes).toBeGreaterThan(0);
    });
  });
});
