import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getMakes,
  getModels,
  searchVehicles,
  getRegisterEntries,
  getEntryDetail,
  searchByChassis,
  getDataStats,
} from "./vehicleData";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  vehicle: router({
    makes: publicProcedure.query(() => {
      return getMakes();
    }),

    models: publicProcedure
      .input(z.object({ make: z.string() }))
      .query(({ input }) => {
        return getModels(input.make);
      }),

    search: publicProcedure
      .input(
        z.object({
          query: z.string().optional(),
          make: z.string().optional(),
          model: z.string().optional(),
          yearFrom: z.number().optional(),
          yearTo: z.number().optional(),
          category: z.string().optional(),
          page: z.number().optional(),
          pageSize: z.number().optional(),
        })
      )
      .query(({ input }) => {
        return searchVehicles(input);
      }),

    registerEntries: publicProcedure
      .input(z.object({ make: z.string(), model: z.string() }))
      .query(({ input }) => {
        return getRegisterEntries(input.make, input.model);
      }),

    detail: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(({ input }) => {
        return getEntryDetail(input.code);
      }),

    chassisSearch: publicProcedure
      .input(z.object({ chassis: z.string() }))
      .query(({ input }) => {
        return searchByChassis(input.chassis);
      }),

    stats: publicProcedure.query(() => {
      return getDataStats();
    }),
  }),
});

export type AppRouter = typeof appRouter;
