import { readFileSync } from "fs";
import { join } from "path";
import type {
  RawData,
  RawMRE,
  RawSEV,
  VehicleSearchResult,
  RegisterEntry,
  VehicleDetail,
  MakeSuggestion,
  ModelSuggestion,
} from "../shared/types";

// Load data once at startup
const dataPath = join(import.meta.dirname, "data.json");
const rawData: RawData = JSON.parse(readFileSync(dataPath, "utf-8"));

// ── Helper functions ──────────────────────────────────────────────────────

function parseMonthYear(str: string): { month: number; year: number } | null {
  if (!str || str === "No end date") return null;
  const parts = str.trim().split("/");
  if (parts.length === 2) {
    return { month: parseInt(parts[0], 10), year: parseInt(parts[1], 10) };
  }
  return null;
}

function parseBuildDateRange(range: string): {
  start: string;
  end: string;
  startYear: number | null;
  endYear: number | null;
} {
  const parts = range.split(" - ").map((s) => s.trim());
  const startParsed = parseMonthYear(parts[0]);
  const endParsed = parts[1] ? parseMonthYear(parts[1]) : null;

  const monthNames = [
    "", "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
  ];

  const startLabel = startParsed
    ? `${monthNames[startParsed.month]} ${startParsed.year}`
    : parts[0] || "Unknown";
  const endLabel = endParsed
    ? `${monthNames[endParsed.month]} ${endParsed.year}`
    : parts[1] === "No end date" || !parts[1]
      ? "Present"
      : parts[1];

  return {
    start: startLabel,
    end: endLabel,
    startYear: startParsed?.year ?? null,
    endYear: endParsed?.year ?? null,
  };
}

function translateStatus(status: string): string {
  const s = status.toLowerCase().trim();
  if (s === "in force") return "Active";
  if (s === "expired") return "Expired";
  if (s === "suspended") return "Suspended";
  if (s === "revoked") return "Revoked";
  return status;
}

function translateCategory(cat: string): string {
  if (!cat) return "General";
  const categoryMap: Record<string, string> = {
    "LC - Motor Cycle": "Motorcycle",
    "LEP - 3 Wheeled L-group Vehicles": "Three-Wheeled Vehicle",
    "MA - Passenger Vehicle": "Passenger Vehicle",
    "MB - Forward-Control Passenger Vehicle": "Forward-Control Passenger Vehicle (e.g. vans)",
    "MC - Off-Road Passenger Vehicle": "Off-Road / 4WD Passenger Vehicle",
    "MD2 - Light Omnibus": "Light Bus (up to 12 seats)",
    "MD3 - Light Omnibus": "Light Bus (up to 12 seats)",
    "MD4 - Light Omnibus": "Light Bus (up to 12 seats)",
    "ME - Heavy Omnibus": "Heavy Bus",
    "NA - Light Goods Vehicle": "Light Commercial / Ute",
    "NB1 - Medium Goods Vehicle": "Medium Truck",
    "NB2 - Medium Goods Vehicle": "Medium Truck",
    "NC - Heavy Goods Vehicle": "Heavy Truck",
  };
  return categoryMap[cat] || cat;
}

function extractChassisCodes(modelCode: string): string[] {
  if (!modelCode) return [];
  return modelCode
    .split(/[,;/]+/)
    .map((c) => c.trim())
    .filter((c) => c.length > 0 && c.length < 20);
}

function normalizeMake(make: string): string {
  return make.trim().toUpperCase();
}

// Filter out RAWS workshop entries that appear as "makes"
function isRealMake(make: string): boolean {
  if (!make || make.trim() === "") return false;
  const lower = make.toLowerCase();
  // Known workshop patterns
  if (lower.includes("a to z rv")) return false;
  if (lower.includes("allied vehicles")) return false;
  if (lower.includes("adam bowes")) return false;
  if (lower.includes("alx horse")) return false;
  if (lower.includes("autotrail")) return false;
  if (lower.includes("bessacarr")) return false;
  if (lower.includes("border coaster")) return false;
  if (lower.includes("burstner")) return false;
  if (lower.includes("chausson")) return false;
  if (lower.includes("elddis")) return false;
  if (lower.includes("glam group")) return false;
  if (lower.includes("swift group")) return false;
  if (lower.includes("roller team")) return false;
  if (lower.includes("pilote")) return false;
  if (lower.includes("dethleffs")) return false;
  if (lower.includes("adria")) return false;
  if (lower.includes("knaus")) return false;
  if (lower.includes("bailey")) return false;
  return true;
}

// ── Build index ───────────────────────────────────────────────────────────

interface VehicleGroup {
  make: string;
  model: string;
  mreRecords: RawMRE[];
  sevRecords: RawSEV[];
}

function buildVehicleIndex(): Map<string, VehicleGroup> {
  const index = new Map<string, VehicleGroup>();

  for (const mre of rawData.mre) {
    const key = `${normalizeMake(mre.Make)}::${mre.Model.trim().toUpperCase()}`;
    if (!index.has(key)) {
      index.set(key, {
        make: mre.Make.trim(),
        model: mre.Model.trim(),
        mreRecords: [],
        sevRecords: [],
      });
    }
    index.get(key)!.mreRecords.push(mre);
  }

  for (const sev of rawData.sev) {
    const key = `${normalizeMake(sev.Make)}::${sev.Model.trim().toUpperCase()}`;
    if (!index.has(key)) {
      index.set(key, {
        make: sev.Make.trim(),
        model: sev.Model.trim(),
        mreRecords: [],
        sevRecords: [],
      });
    }
    index.get(key)!.sevRecords.push(sev);
  }

  return index;
}

const vehicleIndex = buildVehicleIndex();

// ── Public API ────────────────────────────────────────────────────────────

export function getMakes(): MakeSuggestion[] {
  const makeMap = new Map<string, number>();
  for (const entry of Array.from(vehicleIndex.values())) {
    if (!isRealMake(entry.make)) continue;
    const normalized = entry.make.toUpperCase();
    const existing = makeMap.get(normalized) || 0;
    makeMap.set(normalized, existing + entry.mreRecords.length + entry.sevRecords.length);
  }
  return Array.from(makeMap.entries())
    .map(([make, count]) => ({
      make: make.charAt(0) + make.slice(1).toLowerCase(),
      count,
    }))
    .sort((a, b) => a.make.localeCompare(b.make));
}

export function getModels(make: string): ModelSuggestion[] {
  const modelMap = new Map<string, { model: string; count: number }>();
  const normalizedMake = normalizeMake(make);

  for (const group of Array.from(vehicleIndex.values())) {
    if (normalizeMake(group.make) !== normalizedMake) continue;
    const key = group.model.toUpperCase();
    if (!modelMap.has(key)) {
      modelMap.set(key, { model: group.model, count: 0 });
    }
    const entry = modelMap.get(key)!;
    entry.count += group.mreRecords.length + group.sevRecords.length;
  }

  return Array.from(modelMap.values())
    .map((m) => ({ model: m.model, make, count: m.count }))
    .sort((a, b) => a.model.localeCompare(b.model));
}

export function searchVehicles(params: {
  query?: string;
  make?: string;
  model?: string;
  yearFrom?: number;
  yearTo?: number;
  category?: string;
  page?: number;
  pageSize?: number;
}): { results: VehicleSearchResult[]; total: number; page: number; pageSize: number } {
  const { query, make, model, yearFrom, yearTo, category, page = 1, pageSize = 15 } = params;
  const results: VehicleSearchResult[] = [];

  for (const group of Array.from(vehicleIndex.values())) {
    if (!isRealMake(group.make)) continue;

    // Text search
    if (query) {
      const q = query.toLowerCase();
      const haystack = `${group.make} ${group.model}`.toLowerCase();
      if (!haystack.includes(q)) continue;
    }

    // Make filter
    if (make && normalizeMake(group.make) !== normalizeMake(make)) continue;

    // Model filter
    if (model && group.model.toUpperCase() !== model.toUpperCase()) continue;

    // Compute build date range across all records
    let minYear: number | null = null;
    let maxYear: number | null = null;
    const allChassis = new Set<string>();
    const allPropulsion = new Set<string>();

    for (const mre of group.mreRecords) {
      const parsed = parseBuildDateRange(mre["Build date range"]);
      if (parsed.startYear && (!minYear || parsed.startYear < minYear)) minYear = parsed.startYear;
      if (parsed.endYear && (!maxYear || parsed.endYear > maxYear)) maxYear = parsed.endYear;
      if (!parsed.endYear && parsed.startYear) maxYear = new Date().getFullYear();
    }

    for (const sev of group.sevRecords) {
      const startParsed = parseMonthYear(sev["Build date from"]);
      const endParsed = parseMonthYear(sev["Build date to"]);
      if (startParsed && (!minYear || startParsed.year < minYear)) minYear = startParsed.year;
      if (endParsed && (!maxYear || endParsed.year > maxYear)) maxYear = endParsed.year;
      if (!endParsed && startParsed) maxYear = new Date().getFullYear();

      for (const code of extractChassisCodes(sev["Model code"])) {
        allChassis.add(code);
      }

      const cat = (sev.Category || "").toLowerCase();
      if (cat.includes("environment") || cat.includes("ev") || cat.includes("electric")) {
        allPropulsion.add("EV");
      } else if (cat.includes("hybrid")) {
        allPropulsion.add("Hybrid");
      }
    }

    // Year filter
    if (yearFrom && maxYear && maxYear < yearFrom) continue;
    if (yearTo && minYear && minYear > yearTo) continue;

    // Category filter (vehicle type)
    if (category) {
      const catLower = category.toLowerCase();
      let matchesCategory = false;
      for (const sev of group.sevRecords) {
        if (sev.Category.toLowerCase().includes(catLower)) {
          matchesCategory = true;
          break;
        }
      }
      for (const mre of group.mreRecords) {
        if (mre["Post-modification category"].toLowerCase() === catLower) {
          matchesCategory = true;
          break;
        }
      }
      if (!matchesCategory) continue;
    }

    const dateRange =
      minYear && maxYear
        ? `${minYear}${maxYear !== minYear ? ` – ${maxYear === new Date().getFullYear() ? "Present" : maxYear}` : ""}`
        : "Date range not specified";

    results.push({
      id: `${normalizeMake(group.make)}::${group.model.toUpperCase()}`,
      make: group.make,
      model: group.model,
      eligible: group.mreRecords.length > 0 || group.sevRecords.length > 0,
      buildDateRange: dateRange,
      buildYearStart: minYear,
      buildYearEnd: maxYear,
      mreCount: group.mreRecords.length,
      sevCount: group.sevRecords.length,
      chassisCodes: Array.from(allChassis),
      propulsion: allPropulsion.size > 0 ? Array.from(allPropulsion) : ["Petrol"],
    });
  }

  // Sort by make then model
  results.sort((a, b) => {
    const makeComp = a.make.localeCompare(b.make);
    if (makeComp !== 0) return makeComp;
    return a.model.localeCompare(b.model);
  });

  const total = results.length;
  const start = (page - 1) * pageSize;
  const paged = results.slice(start, start + pageSize);

  return { results: paged, total, page, pageSize };
}

export function getRegisterEntries(make: string, model: string): RegisterEntry[] {
  const entries: RegisterEntry[] = [];
  const normalizedMake = normalizeMake(make);

  for (const group of Array.from(vehicleIndex.values())) {
    if (normalizeMake(group.make) !== normalizedMake) continue;
    if (group.model.toUpperCase() !== model.toUpperCase()) continue;

    for (const mre of group.mreRecords) {
      const parsed = parseBuildDateRange(mre["Build date range"]);
      entries.push({
        id: mre["Approval number"],
        type: "MRE",
        code: mre["Approval number"],
        label: mre._workshop_short || mre._approval_holder || `Compliance Workshop ${mre["Approval number"]}`,
        status: mre["Approval status"],
        statusLabel: translateStatus(mre["Approval status"]),
        make: group.make,
        model: group.model,
        buildDateRange: `${parsed.start} – ${parsed.end}`,
        chassisCodes: [],
        complianceLevel: mre["Compliance Level"],
        workshopName: mre._workshop_short || mre._approval_holder,
        detailUrl: mre._detail_url,
      });
    }

    for (const sev of group.sevRecords) {
      const startParsed = parseMonthYear(sev["Build date from"]);
      const endParsed = parseMonthYear(sev["Build date to"]);
      const monthNames = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const startLabel = startParsed ? `${monthNames[startParsed.month]} ${startParsed.year}` : "Unknown";
      const endLabel = endParsed ? `${monthNames[endParsed.month]} ${endParsed.year}` : "Present";

      entries.push({
        id: sev["SEV #"],
        type: "SEV",
        code: sev["SEV #"],
        label: `${translateCategory(sev.Category)} — ${sev["Model code"] || group.model}`,
        status: "In Force",
        statusLabel: "Active",
        make: group.make,
        model: group.model,
        buildDateRange: `${startLabel} – ${endLabel}`,
        chassisCodes: extractChassisCodes(sev["Model code"]),
        category: translateCategory(sev.Category),
        expiry: sev.Expiry,
        underReview: sev["Under review"] === "Yes",
        detailUrl: sev._detail_url,
      });
    }
  }

  return entries;
}

export function getEntryDetail(code: string): VehicleDetail | null {
  // Search MRE records
  for (const mre of rawData.mre) {
    if (mre["Approval number"] === code) {
      const parsed = parseBuildDateRange(mre["Build date range"]);
      return {
        id: mre["Approval number"],
        type: "MRE",
        code: mre["Approval number"],
        label: mre._workshop_short || mre._approval_holder || `Compliance Workshop ${mre["Approval number"]}`,
        status: mre["Approval status"],
        statusLabel: translateStatus(mre["Approval status"]),
        make: mre.Make.trim(),
        model: mre.Model.trim(),
        buildDateRange: `${parsed.start} – ${parsed.end}`,
        chassisCodes: [],
        complianceLevel: mre["Compliance Level"],
        workshopName: mre._workshop_short || mre._approval_holder,
        detailUrl: mre._detail_url,
        modelReportType: mre["Model report type"],
        postModCategory: mre["Post-modification category"],
      };
    }
  }

  // Search SEV records
  for (const sev of rawData.sev) {
    if (sev["SEV #"] === code) {
      const startParsed = parseMonthYear(sev["Build date from"]);
      const endParsed = parseMonthYear(sev["Build date to"]);
      const monthNames = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const startLabel = startParsed ? `${monthNames[startParsed.month]} ${startParsed.year}` : "Unknown";
      const endLabel = endParsed ? `${monthNames[endParsed.month]} ${endParsed.year}` : "Present";

      return {
        id: sev["SEV #"],
        type: "SEV",
        code: sev["SEV #"],
        label: `${translateCategory(sev.Category)} — ${sev["Model code"] || sev.Model.trim()}`,
        status: "In Force",
        statusLabel: "Active",
        make: sev.Make.trim(),
        model: sev.Model.trim(),
        buildDateRange: `${startLabel} – ${endLabel}`,
        chassisCodes: extractChassisCodes(sev["Model code"]),
        category: translateCategory(sev.Category),
        expiry: sev.Expiry,
        underReview: sev["Under review"] === "Yes",
        detailUrl: sev._detail_url,
        sevCategory: sev._sev_category || sev.Category,
      };
    }
  }

  return null;
}

export function searchByChassis(chassisCode: string): RegisterEntry[] {
  const results: RegisterEntry[] = [];
  const query = chassisCode.trim().toUpperCase();
  if (!query || query.length < 2) return results;

  for (const sev of rawData.sev) {
    const codes = extractChassisCodes(sev["Model code"]);
    const match = codes.some((c) => c.toUpperCase().includes(query));
    if (!match) continue;

    const startParsed = parseMonthYear(sev["Build date from"]);
    const endParsed = parseMonthYear(sev["Build date to"]);
    const monthNames = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const startLabel = startParsed ? `${monthNames[startParsed.month]} ${startParsed.year}` : "Unknown";
    const endLabel = endParsed ? `${monthNames[endParsed.month]} ${endParsed.year}` : "Present";

    results.push({
      id: sev["SEV #"],
      type: "SEV",
      code: sev["SEV #"],
      label: `${translateCategory(sev.Category)} — ${sev["Model code"] || sev.Model.trim()}`,
      status: "In Force",
      statusLabel: "Active",
      make: sev.Make.trim(),
      model: sev.Model.trim(),
      buildDateRange: `${startLabel} – ${endLabel}`,
      chassisCodes: codes,
      category: translateCategory(sev.Category),
      expiry: sev.Expiry,
      underReview: sev["Under review"] === "Yes",
      detailUrl: sev._detail_url,
    });
  }

  return results;
}

export function getDataStats() {
  return {
    fetchedAt: rawData.fetched_at,
    mreCount: rawData.mre.length,
    sevCount: rawData.sev.length,
    totalMakes: getMakes().length,
  };
}
