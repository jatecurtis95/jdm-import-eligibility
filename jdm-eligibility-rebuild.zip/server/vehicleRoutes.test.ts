import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("vehicle tRPC routes", () => {
  const ctx = createPublicContext();
  const caller = appRouter.createCaller(ctx);

  describe("vehicle.makes", () => {
    it("returns a non-empty array of makes", async () => {
      const makes = await caller.vehicle.makes();
      expect(Array.isArray(makes)).toBe(true);
      expect(makes.length).toBeGreaterThan(0);
    });

    it("each make has make and count fields", async () => {
      const makes = await caller.vehicle.makes();
      for (const m of makes.slice(0, 5)) {
        expect(m).toHaveProperty("make");
        expect(m).toHaveProperty("count");
        expect(typeof m.make).toBe("string");
        expect(typeof m.count).toBe("number");
      }
    });

    it("includes Toyota", async () => {
      const makes = await caller.vehicle.makes();
      const toyota = makes.find((m) => m.make === "Toyota");
      expect(toyota).toBeDefined();
      expect(toyota!.count).toBeGreaterThan(0);
    });
  });

  describe("vehicle.models", () => {
    it("returns models for Toyota", async () => {
      const models = await caller.vehicle.models({ make: "Toyota" });
      expect(Array.isArray(models)).toBe(true);
      expect(models.length).toBeGreaterThan(0);
    });

    it("includes Alphard for Toyota", async () => {
      const models = await caller.vehicle.models({ make: "Toyota" });
      const alphard = models.find((m) => m.model === "Alphard");
      expect(alphard).toBeDefined();
    });

    it("is case-insensitive for make", async () => {
      const models1 = await caller.vehicle.models({ make: "Toyota" });
      const models2 = await caller.vehicle.models({ make: "toyota" });
      expect(models1.length).toBe(models2.length);
    });

    it("returns empty array for unknown make", async () => {
      const models = await caller.vehicle.models({ make: "NonExistentMake" });
      expect(models).toEqual([]);
    });
  });

  describe("vehicle.search", () => {
    it("returns results for Toyota", async () => {
      const result = await caller.vehicle.search({ make: "Toyota" });
      expect(result.results.length).toBeGreaterThan(0);
      expect(result.total).toBeGreaterThan(0);
      expect(result.page).toBe(1);
    });

    it("paginates correctly", async () => {
      const page1 = await caller.vehicle.search({ make: "Toyota", pageSize: 5, page: 1 });
      const page2 = await caller.vehicle.search({ make: "Toyota", pageSize: 5, page: 2 });
      expect(page1.results.length).toBe(5);
      expect(page2.results.length).toBeGreaterThan(0);
      expect(page1.results[0].id).not.toBe(page2.results[0].id);
    });

    it("filters by model", async () => {
      const result = await caller.vehicle.search({ make: "Toyota", model: "Alphard" });
      expect(result.total).toBeGreaterThan(0);
      for (const r of result.results) {
        expect(r.model.toLowerCase()).toContain("alphard");
      }
    });

    it("filters by year", async () => {
      const result = await caller.vehicle.search({ make: "Toyota", yearFrom: 2020 });
      expect(result.total).toBeGreaterThan(0);
      for (const r of result.results) {
        // buildYearEnd should be >= 2020 for all results
        if (r.buildYearEnd !== null) {
          expect(r.buildYearEnd).toBeGreaterThanOrEqual(2020);
        }
      }
    });

    it("each result has required fields", async () => {
      const result = await caller.vehicle.search({ make: "Toyota", pageSize: 3 });
      for (const r of result.results) {
        expect(r).toHaveProperty("id");
        expect(r).toHaveProperty("make");
        expect(r).toHaveProperty("model");
        expect(r).toHaveProperty("eligible");
        expect(r).toHaveProperty("buildDateRange");
        expect(r).toHaveProperty("mreCount");
        expect(r).toHaveProperty("sevCount");
        expect(typeof r.eligible).toBe("boolean");
      }
    });
  });

  describe("vehicle.registerEntries", () => {
    it("returns entries for Toyota Alphard", async () => {
      const entries = await caller.vehicle.registerEntries({ make: "Toyota", model: "Alphard" });
      expect(Array.isArray(entries)).toBe(true);
      expect(entries.length).toBeGreaterThan(0);
    });

    it("entries have correct types (SEV or MRE)", async () => {
      const entries = await caller.vehicle.registerEntries({ make: "Toyota", model: "Alphard" });
      for (const e of entries) {
        expect(["SEV", "MRE"]).toContain(e.type);
        expect(e).toHaveProperty("code");
        expect(e).toHaveProperty("label");
        expect(e).toHaveProperty("buildDateRange");
        expect(e).toHaveProperty("statusLabel");
      }
    });

    it("returns empty for unknown model", async () => {
      const entries = await caller.vehicle.registerEntries({ make: "Toyota", model: "NonExistentModel" });
      expect(entries).toEqual([]);
    });
  });

  describe("vehicle.detail", () => {
    it("returns detail for a known MRE code", async () => {
      const detail = await caller.vehicle.detail({ code: "MRE-000014" });
      expect(detail).not.toBeNull();
      expect(detail!.type).toBe("MRE");
      expect(detail!.make).toBe("Toyota");
      expect(detail!.model).toBe("Alphard");
      expect(detail!.statusLabel).toBeDefined();
    });

    it("returns detail for a known SEV code", async () => {
      const detail = await caller.vehicle.detail({ code: "SEV-000440" });
      expect(detail).not.toBeNull();
      expect(detail!.type).toBe("SEV");
      expect(detail!.chassisCodes.length).toBeGreaterThan(0);
    });

    it("returns null for unknown code", async () => {
      const detail = await caller.vehicle.detail({ code: "NONEXISTENT-999" });
      expect(detail).toBeNull();
    });
  });

  describe("vehicle.chassisSearch", () => {
    it("finds vehicles by chassis code", async () => {
      const results = await caller.vehicle.chassisSearch({ chassis: "JZX100" });
      expect(Array.isArray(results)).toBe(true);
      expect(results.length).toBeGreaterThan(0);
      for (const r of results) {
        const hasMatch = r.chassisCodes.some((c: string) => c.toUpperCase().includes("JZX100"));
        expect(hasMatch).toBe(true);
      }
    });

    it("returns empty for unknown chassis", async () => {
      const results = await caller.vehicle.chassisSearch({ chassis: "ZZZZZZZ" });
      expect(results).toEqual([]);
    });

    it("is case-insensitive", async () => {
      const upper = await caller.vehicle.chassisSearch({ chassis: "JZX100" });
      const lower = await caller.vehicle.chassisSearch({ chassis: "jzx100" });
      expect(upper.length).toBe(lower.length);
    });
  });

  describe("vehicle.stats", () => {
    it("returns data statistics", async () => {
      const stats = await caller.vehicle.stats();
      expect(stats).toHaveProperty("mreCount");
      expect(stats).toHaveProperty("sevCount");
      expect(stats).toHaveProperty("totalMakes");
      expect(stats.mreCount).toBeGreaterThan(0);
      expect(stats.sevCount).toBeGreaterThan(0);
      expect(stats.totalMakes).toBeGreaterThan(0);
    });
  });
});
