import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import Layout from "@/components/Layout";
import {
  CheckCircle2,
  XCircle,
  Loader2,
  ExternalLink,
  HelpCircle,
  Calendar,
  ShieldCheck,
  FileText,
  AlertTriangle,
  ChevronDown,
  Wrench,
  MapPin,
  ArrowLeft,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { useState } from "react";

const QUOTE_URL = "https://jdmconnect.com.au/get-a-quote/";

function InfoRow({ label, value, tooltip }: { label: string; value: string | undefined; tooltip?: string }) {
  if (!value) return null;
  return (
    <div className="flex items-start justify-between py-3 border-b border-border/30 last:border-0">
      <div className="flex items-center gap-1.5 text-sm text-muted-foreground shrink-0 mr-4">
        {label}
        {tooltip && (
          <Tooltip>
            <TooltipTrigger>
              <HelpCircle className="w-3.5 h-3.5 text-muted-foreground/50" />
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p>{tooltip}</p>
            </TooltipContent>
          </Tooltip>
        )}
      </div>
      <span className="text-sm font-medium text-foreground text-right">{value}</span>
    </div>
  );
}

function Explainer({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <CollapsibleTrigger className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors w-full py-2">
        <HelpCircle className="w-4 h-4 shrink-0" />
        <span className="font-medium">{title}</span>
        <ChevronDown className={`w-4 h-4 ml-auto transition-transform ${open ? "rotate-180" : ""}`} />
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="text-sm text-muted-foreground leading-relaxed pb-3 pl-6">
          {children}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

export default function VehicleDetail() {
  const [, navigate] = useLocation();
  const params = useParams<{ code: string }>();
  const code = decodeURIComponent(params.code || "");

  const { data: detail, isLoading } = trpc.vehicle.detail.useQuery(
    { code },
    { enabled: !!code }
  );

  const breadcrumbs = detail
    ? [
        { label: "Search", href: "/" },
        { label: detail.make, href: `/search?make=${encodeURIComponent(detail.make)}` },
        {
          label: detail.model,
          href: `/vehicle/${encodeURIComponent(detail.make)}/${encodeURIComponent(detail.model)}`,
        },
        { label: detail.type === "SEV" ? `SEV #${detail.code}` : `MRE #${detail.code}` },
      ]
    : [{ label: "Search", href: "/" }, { label: "Loading..." }];

  if (isLoading) {
    return (
      <Layout breadcrumbs={breadcrumbs} step={3}>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <span className="ml-3 text-muted-foreground">Loading vehicle details...</span>
        </div>
      </Layout>
    );
  }

  if (!detail) {
    return (
      <Layout breadcrumbs={breadcrumbs} step={3}>
        <div className="text-center py-16">
          <XCircle className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Entry not found</h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
            The register entry you're looking for could not be found. It may have been removed or the code is incorrect.
          </p>
          <Button onClick={() => navigate("/")} variant="outline" className="border-border/60">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to Search
          </Button>
        </div>
      </Layout>
    );
  }

  const isActive = detail.statusLabel === "Active";
  const isSEV = detail.type === "SEV";

  return (
    <Layout breadcrumbs={breadcrumbs} step={3}>
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <span
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold ${
              isSEV
                ? "bg-blue-500/15 text-blue-400 border border-blue-500/20"
                : "bg-primary/15 text-primary border border-primary/20"
            }`}
          >
            {isSEV ? <ShieldCheck className="w-3.5 h-3.5" /> : <FileText className="w-3.5 h-3.5" />}
            {isSEV ? "SEVS Entry" : "MRE Entry"}
          </span>
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
              isActive
                ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20"
                : "bg-red-500/15 text-red-400 border border-red-500/20"
            }`}
          >
            {isActive ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
            {detail.statusLabel}
          </span>
          {detail.underReview && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/20">
              <AlertTriangle className="w-3.5 h-3.5" />
              Under Review
            </span>
          )}
        </div>
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-foreground">
          {detail.make} {detail.model}
        </h1>
        <p className="text-base text-muted-foreground mt-1">{detail.label}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Core Info Card */}
          <div className="bg-card border border-border/60 rounded-xl p-5 sm:p-6">
            <h2 className="text-base font-semibold text-foreground mb-4 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" />
              Vehicle Details
            </h2>
            <div className="divide-y divide-border/30">
              <InfoRow label="Register Type" value={isSEV ? "SEVS (Specialist & Enthusiast Vehicle Scheme)" : "MRE (Model Report Eligibility)"} />
              <InfoRow
                label="Status"
                value={detail.statusLabel}
                tooltip={
                  isActive
                    ? "This entry is currently active, meaning vehicles matching this specification can be imported."
                    : "This entry is no longer active. Vehicles may not be importable under this entry."
                }
              />
              <InfoRow label="Entry Code" value={`#${detail.code}`} />
              <InfoRow label="Make" value={detail.make} />
              <InfoRow label="Model" value={detail.model} />
              <InfoRow
                label="Build Date Range"
                value={detail.buildDateRange}
                tooltip="The range of manufacture dates covered by this register entry. Your vehicle must have been built within this range to qualify."
              />
              {detail.complianceLevel && (
                <InfoRow
                  label="Compliance Level"
                  value={detail.complianceLevel}
                  tooltip="The level of compliance testing required. Full compliance means the vehicle meets all Australian Design Rules (ADRs)."
                />
              )}
              {detail.category && (
                <InfoRow
                  label="Category"
                  value={detail.category}
                  tooltip="The vehicle category under SEVS. This determines which import pathway applies."
                />
              )}
              {detail.modelReportType && (
                <InfoRow label="Report Type" value={detail.modelReportType} />
              )}
              {detail.postModCategory && (
                <InfoRow
                  label="Post-modification"
                  value={detail.postModCategory}
                  tooltip="Whether modifications are required after import to meet Australian standards."
                />
              )}
              {detail.expiry && detail.expiry !== "N/A" && (
                <InfoRow
                  label="Expiry"
                  value={detail.expiry}
                  tooltip="The date this register entry expires. After this date, new imports under this entry may not be accepted."
                />
              )}
            </div>
          </div>

          {/* Chassis Codes */}
          {detail.chassisCodes.length > 0 && (
            <div className="bg-card border border-border/60 rounded-xl p-5 sm:p-6">
              <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
                Chassis / Model Codes
              </h2>
              <p className="text-sm text-muted-foreground mb-4">
                These are the specific chassis codes (also known as model codes) covered by this register entry.
                Your vehicle's chassis code must match one of these to qualify.
              </p>
              <div className="flex flex-wrap gap-2">
                {detail.chassisCodes.map((code) => (
                  <span
                    key={code}
                    className="inline-flex items-center px-3 py-1.5 rounded-lg bg-secondary/60 text-foreground font-mono text-sm border border-border/30"
                  >
                    {code}
                  </span>
                ))}
              </div>
              <Explainer title="What is a chassis code?">
                A chassis code (or model code) is a short alphanumeric identifier that describes the exact specification
                of your vehicle — including engine type, body style, and drivetrain. For example, "JZX100" refers to
                a Toyota Chaser with a 1JZ engine. You can find your chassis code on the vehicle's compliance plate,
                registration documents, or by checking the VIN.
              </Explainer>
            </div>
          )}

          {/* Workshop Info (MRE) */}
          {detail.type === "MRE" && detail.workshopName && (
            <div className="bg-card border border-border/60 rounded-xl p-5 sm:p-6">
              <h2 className="text-base font-semibold text-foreground mb-3 flex items-center gap-2">
                <Wrench className="w-4 h-4 text-primary" />
                Approved Compliance Workshop
              </h2>
              <p className="text-sm text-muted-foreground mb-4">
                This workshop has been approved by the Australian Government to import and certify this vehicle model.
              </p>
              <div className="bg-secondary/30 border border-border/30 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{detail.workshopName}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      Approval #{detail.code} — {detail.statusLabel}
                    </p>
                  </div>
                </div>
              </div>
              <Explainer title="What is a compliance workshop?">
                A compliance workshop (also called a RAWS — Registered Automotive Workshop Scheme) is a government-approved
                facility that can modify and certify imported vehicles to meet Australian Design Rules (ADRs). You must use
                an approved workshop to legally import a vehicle under this entry.
              </Explainer>
            </div>
          )}

          {/* Explainers */}
          <div className="bg-card border border-border/60 rounded-xl p-5 sm:p-6">
            <h2 className="text-base font-semibold text-foreground mb-3">Understanding This Entry</h2>
            <div className="space-y-1">
              {isSEV && (
                <Explainer title="What does SEVS mean?">
                  The Specialist and Enthusiast Vehicle Scheme (SEVS) is an Australian Government program that allows
                  certain vehicle types to be imported that are not otherwise available in Australia. Vehicles must be
                  listed on the SEVS register to be eligible. The scheme covers categories like enthusiast vehicles,
                  specialist vehicles, and low-emission vehicles.
                </Explainer>
              )}
              {!isSEV && (
                <Explainer title="What does MRE mean?">
                  Model Report Eligibility (MRE) is the approval given to a specific compliance workshop to import
                  and certify a particular vehicle model. Each MRE entry specifies which models, build dates, and
                  compliance levels the workshop is approved for.
                </Explainer>
              )}
              <Explainer title="What does the build date range mean?">
                The build date range specifies which manufacture dates are covered by this register entry.
                Your vehicle must have been manufactured within this date range to be eligible for import
                under this specific entry. The build date is determined by the vehicle's manufacture date in Japan,
                not when it was first registered.
              </Explainer>
              <Explainer title="What happens after I find an eligible vehicle?">
                Once you've confirmed your vehicle is on the register, the next steps are: (1) Contact JDM Connect
                for a quote, (2) Source the vehicle in Japan, (3) Ship it to Australia, (4) Have it processed through
                an approved compliance workshop, (5) Register it in your state. JDM Connect handles the entire process
                from start to finish.
              </Explainer>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* CTA Card */}
          <div className="bg-gradient-to-b from-primary/10 to-primary/5 border border-primary/20 rounded-xl p-6 text-center sticky top-24">
            <h3 className="text-lg font-semibold text-foreground mb-2">
              {isActive ? "Import this vehicle" : "Need help?"}
            </h3>
            <p className="text-sm text-muted-foreground mb-5 leading-relaxed">
              {isActive
                ? `JDM Connect can source, ship, and comply a ${detail.make} ${detail.model} for you — from Japan to your door.`
                : "Even if this entry is no longer active, there may be other pathways. Contact JDM Connect to discuss your options."}
            </p>
            <a href={QUOTE_URL} target="_blank" rel="noopener noreferrer" className="block">
              <Button size="lg" className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold h-12">
                Get a Free Quote
                <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
            </a>
            <p className="text-xs text-muted-foreground mt-3">
              No obligation — we'll respond within 24 hours.
            </p>
          </div>

          {/* Quick Facts */}
          <div className="bg-card border border-border/60 rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Quick Summary</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                {isActive ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                )}
                <span className="text-muted-foreground">
                  {isActive ? "Currently eligible for import" : "Entry no longer active"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary shrink-0" />
                <span className="text-muted-foreground">Build: {detail.buildDateRange}</span>
              </div>
              {detail.type === "MRE" && detail.workshopName && (
                <div className="flex items-center gap-2">
                  <Wrench className="w-4 h-4 text-primary shrink-0" />
                  <span className="text-muted-foreground">{detail.workshopName}</span>
                </div>
              )}
            </div>
          </div>

          {/* Official Source */}
          {detail.detailUrl && (
            <div className="bg-card border border-border/60 rounded-xl p-5">
              <h3 className="text-sm font-semibold text-foreground mb-3">Official Source</h3>
              <a
                href={detail.detailUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-primary hover:text-primary/80 transition-colors flex items-center gap-1.5"
              >
                View on ROVER Register
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <p className="text-xs text-muted-foreground mt-2">
                Official government register maintained by the Department of Infrastructure.
              </p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
