import { useState, useMemo } from "react";
import { useLocation, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import Layout from "@/components/Layout";
import { CheckCircle2, XCircle, ChevronLeft, ChevronRight, ArrowRight, Loader2, HelpCircle, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const QUOTE_URL = "https://jdmconnect.com.au/get-a-quote/";

export default function SearchResults() {
  const [, navigate] = useLocation();
  const searchString = useSearch();
  const params = useMemo(() => new URLSearchParams(searchString), [searchString]);

  const make = params.get("make") || "";
  const model = params.get("model") || "";
  const query = params.get("q") || "";
  const chassis = params.get("chassis") || "";
  const yearFromParam = params.get("yearFrom");
  const yearFrom = yearFromParam ? parseInt(yearFromParam) : undefined;
  const category = params.get("category") || "";

  const [page, setPage] = useState(1);

  // Chassis search mode
  const isChassis = !!chassis;
  const { data: chassisResults, isLoading: chassisLoading } = trpc.vehicle.chassisSearch.useQuery(
    { chassis },
    { enabled: isChassis }
  );

  // Make/model search mode
  const { data: searchData, isLoading: searchLoading } = trpc.vehicle.search.useQuery(
    { make: make || undefined, model: model || undefined, query: query || undefined, yearFrom, category: category || undefined, page, pageSize: 15 },
    { enabled: !isChassis }
  );

  const isLoading = isChassis ? chassisLoading : searchLoading;

  const breadcrumbs = [
    { label: "Search", href: "/" },
    { label: isChassis ? `Chassis: ${chassis}` : make ? `${make}${model ? ` ${model}` : ""}` : "Results" },
  ];

  const title = isChassis
    ? `Results for chassis code "${chassis}"`
    : make
      ? `${make}${model ? ` ${model}` : ""} — Eligibility Results`
      : "Search Results";

  // For chassis mode, group results by make/model
  const chassisGrouped = useMemo(() => {
    if (!chassisResults) return [];
    const groups = new Map<string, typeof chassisResults>();
    for (const entry of chassisResults) {
      const key = `${entry.make}::${entry.model}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(entry);
    }
    return Array.from(groups.entries()).map(([key, entries]) => ({
      make: entries[0].make,
      model: entries[0].model,
      entries,
    }));
  }, [chassisResults]);

  return (
    <Layout breadcrumbs={breadcrumbs} step={1}>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-foreground mb-2">
          {title}
        </h1>
        {!isChassis && searchData && (
          <p className="text-sm text-muted-foreground">
            {searchData.total} vehicle{searchData.total !== 1 ? "s" : ""} found
            {yearFrom ? ` for year ${yearFrom}+` : ""}
          </p>
        )}
        {isChassis && chassisResults && (
          <p className="text-sm text-muted-foreground">
            {chassisResults.length} register {chassisResults.length !== 1 ? "entries" : "entry"} found
          </p>
        )}
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <span className="ml-3 text-muted-foreground">Searching the register...</span>
        </div>
      )}

      {/* Chassis Results */}
      {isChassis && !chassisLoading && chassisGrouped.length > 0 && (
        <div className="space-y-3">
          {chassisGrouped.map((group) => (
            <button
              key={`${group.make}::${group.model}`}
              onClick={() => navigate(`/vehicle/${encodeURIComponent(group.make)}/${encodeURIComponent(group.model)}`)}
              className="w-full text-left bg-card border border-border/60 rounded-xl p-5 sm:p-6 hover:border-primary/40 transition-all group"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Eligible
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                    {group.make} {group.model}
                  </h3>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {group.entries.slice(0, 3).map((e) => (
                      <span key={e.id} className="text-xs px-2 py-1 rounded bg-secondary/60 text-muted-foreground">
                        {e.chassisCodes.join(", ")}
                      </span>
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    {group.entries.length} register {group.entries.length !== 1 ? "entries" : "entry"}
                  </p>
                </div>
                <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors shrink-0 mt-1" />
              </div>
            </button>
          ))}
        </div>
      )}

      {/* No chassis results */}
      {isChassis && !chassisLoading && chassisGrouped.length === 0 && (
        <div className="text-center py-16">
          <XCircle className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No results found</h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
            No vehicles matching chassis code "{chassis}" were found on the register. Try searching by make and model instead,
            or contact JDM Connect for assistance.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button onClick={() => navigate("/")} variant="outline" className="border-border/60">
              <ChevronLeft className="w-4 h-4 mr-1" />
              New Search
            </Button>
            <a href={QUOTE_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-1 rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:bg-primary/90 transition-colors">
                Ask JDM Connect
                <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      )}

      {/* Make/Model Results */}
      {!isChassis && !searchLoading && searchData && (
        <>
          <div className="space-y-3">
            {searchData.results.map((vehicle) => (
              <button
                key={vehicle.id}
                onClick={() => navigate(`/vehicle/${encodeURIComponent(vehicle.make)}/${encodeURIComponent(vehicle.model)}`)}
                className="w-full text-left bg-card border border-border/60 rounded-xl p-5 sm:p-6 hover:border-primary/40 transition-all group"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                          vehicle.eligible
                            ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/20"
                            : "bg-red-500/15 text-red-400 border border-red-500/20"
                        }`}
                      >
                        {vehicle.eligible ? (
                          <><CheckCircle2 className="w-3.5 h-3.5" /> Eligible</>
                        ) : (
                          <><XCircle className="w-3.5 h-3.5" /> Not Eligible</>
                        )}
                      </span>
                      {vehicle.mreCount > 0 && (
                        <span className="text-xs px-2 py-0.5 rounded bg-primary/10 text-primary border border-primary/20" title={`${vehicle.mreCount} approved compliance workshop${vehicle.mreCount !== 1 ? "s" : ""} can import this vehicle`}>
                          {vehicle.mreCount} workshop{vehicle.mreCount !== 1 ? "s" : ""}
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {vehicle.make} {vehicle.model}
                    </h3>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-sm text-muted-foreground">
                      <span>Build: {vehicle.buildDateRange}</span>
                      {vehicle.sevCount > 0 && (
                        <span>{vehicle.sevCount} register {vehicle.sevCount !== 1 ? "entries" : "entry"}</span>
                      )}
                    </div>
                    {vehicle.chassisCodes.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {vehicle.chassisCodes.slice(0, 5).map((code) => (
                          <span key={code} className="text-xs px-2 py-0.5 rounded bg-secondary/60 text-muted-foreground font-mono">
                            {code}
                          </span>
                        ))}
                        {vehicle.chassisCodes.length > 5 && (
                          <span className="text-xs px-2 py-0.5 text-muted-foreground">
                            +{vehicle.chassisCodes.length - 5} more
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors shrink-0 mt-1" />
                </div>
              </button>
            ))}
          </div>

          {/* Pagination */}
          {searchData.total > searchData.pageSize && (
            <div className="flex items-center justify-center gap-4 mt-8">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
                className="border-border/60"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Previous
              </Button>
              <span className="text-sm text-muted-foreground">
                Page {searchData.page} of {Math.ceil(searchData.total / searchData.pageSize)}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage((p) => p + 1)}
                disabled={page >= Math.ceil(searchData.total / searchData.pageSize)}
                className="border-border/60"
              >
                Next
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          )}

          {/* No results */}
          {searchData.results.length === 0 && (
            <div className="text-center py-16">
              <XCircle className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">No vehicles found</h3>
              <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
                No matching vehicles were found on the register. Try broadening your search or contact JDM Connect for assistance.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button onClick={() => navigate("/")} variant="outline" className="border-border/60">
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  New Search
                </Button>
                <a href={QUOTE_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-1 rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:bg-primary/90 transition-colors">
                    Ask JDM Connect
                    <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          )}
        </>
      )}

      {/* Mobile sticky CTA */}
      <div className="fixed bottom-0 left-0 right-0 sm:hidden bg-background/90 backdrop-blur-lg border-t border-border/50 p-3 z-40">
        <a href={QUOTE_URL} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 w-full h-12 rounded-md bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors">
            Get a Quote from JDM Connect
            <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    </Layout>
  );
}
