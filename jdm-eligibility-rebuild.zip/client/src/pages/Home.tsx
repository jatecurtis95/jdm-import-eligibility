import { useState, useMemo, useCallback } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import Layout from "@/components/Layout";
import { Search, ChevronDown, Car, FileText, HelpCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const LOGO_GOLD = "/manus-storage/Lockup_Gold@4x_0920567c.png";

export default function Home() {
  const [, navigate] = useLocation();
  const [searchTab, setSearchTab] = useState<string>("make-model");

  // Make/Model search state
  const [makeQuery, setMakeQuery] = useState("");
  const [selectedMake, setSelectedMake] = useState("");
  const [selectedModel, setSelectedModel] = useState("");
  const [yearFrom, setYearFrom] = useState<string>("");
  const [vehicleType, setVehicleType] = useState<string>("");
  const [showMakeDropdown, setShowMakeDropdown] = useState(false);

  // Chassis search state
  const [chassisQuery, setChassisQuery] = useState("");

  // Data
  const { data: makes } = trpc.vehicle.makes.useQuery();
  const { data: models } = trpc.vehicle.models.useQuery(
    { make: selectedMake },
    { enabled: !!selectedMake }
  );
  const { data: stats } = trpc.vehicle.stats.useQuery();

  const filteredMakes = useMemo(() => {
    if (!makes) return [];
    if (!makeQuery) return makes;
    const q = makeQuery.toLowerCase();
    return makes.filter((m) => m.make.toLowerCase().includes(q));
  }, [makes, makeQuery]);

  const handleMakeSelect = useCallback((make: string) => {
    setSelectedMake(make);
    setMakeQuery(make);
    setSelectedModel("");
    setShowMakeDropdown(false);
  }, []);

  const handleSearch = useCallback(() => {
    const params = new URLSearchParams();
    if (selectedMake) params.set("make", selectedMake);
    if (selectedModel) params.set("model", selectedModel);
    if (yearFrom) params.set("yearFrom", yearFrom);
    if (vehicleType) params.set("category", vehicleType);
    navigate(`/search?${params.toString()}`);
  }, [selectedMake, selectedModel, yearFrom, vehicleType, navigate]);

  const handleChassisSearch = useCallback(() => {
    if (!chassisQuery.trim()) return;
    navigate(`/search?chassis=${encodeURIComponent(chassisQuery.trim())}`);
  }, [chassisQuery, navigate]);

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: currentYear - 1989 }, (_, i) => currentYear - i);

  return (
    <Layout>
      {/* Hero Section */}
      <div className="flex flex-col items-center text-center pt-8 sm:pt-16 pb-10 sm:pb-16">
        <img src={LOGO_GOLD} alt="JDM Connect" className="h-12 sm:h-16 mb-8" />
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-foreground mb-4 leading-tight">
          Import Eligibility Checker
        </h1>
        <p className="text-base sm:text-lg text-muted-foreground max-w-2xl leading-relaxed">
          Check whether a vehicle is eligible for import into Australia. Search the live government
          register by make, model, or chassis code.
        </p>
      </div>

      {/* Search Card */}
      <div className="max-w-2xl mx-auto">
        <div className="bg-card border border-border/60 rounded-xl p-6 sm:p-8 shadow-lg shadow-black/20">
          <Tabs value={searchTab} onValueChange={setSearchTab}>
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-secondary/50">
              <TabsTrigger value="make-model" className="gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <Car className="w-4 h-4" />
                Make &amp; Model
              </TabsTrigger>
              <TabsTrigger value="chassis" className="gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                <FileText className="w-4 h-4" />
                Chassis / VIN
              </TabsTrigger>
            </TabsList>

            <TabsContent value="make-model" className="space-y-4">
              {/* Make Input */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                  Vehicle Make
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Type to search make (e.g. Toyota, Nissan)..."
                    value={makeQuery}
                    onChange={(e) => {
                      setMakeQuery(e.target.value);
                      setSelectedMake("");
                      setSelectedModel("");
                      setShowMakeDropdown(true);
                    }}
                    onFocus={() => setShowMakeDropdown(true)}
                    className="pl-10 h-12 bg-secondary/30 border-border/60 text-base"
                  />
                  {showMakeDropdown && filteredMakes.length > 0 && !selectedMake && (
                    <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-lg shadow-xl max-h-60 overflow-y-auto">
                      {filteredMakes.slice(0, 20).map((m) => (
                        <button
                          key={m.make}
                          onClick={() => handleMakeSelect(m.make)}
                          className="w-full text-left px-4 py-3 text-sm hover:bg-accent transition-colors flex items-center justify-between"
                        >
                          <span className="font-medium">{m.make}</span>
                          <span className="text-xs text-muted-foreground">{m.count} entries</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Model Select */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground">Model</label>
                <div className="relative">
                  <select
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    disabled={!selectedMake}
                    className="w-full h-12 rounded-md border border-border/60 bg-secondary/30 px-4 text-base appearance-none disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    <option value="">{selectedMake ? "All models" : "Select a make first"}</option>
                    {models?.map((m) => (
                      <option key={m.model} value={m.model}>
                        {m.model}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                </div>
              </div>

              {/* Year Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                  Build Year
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-3.5 h-3.5 text-muted-foreground/60" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p>The year the vehicle was manufactured in Japan. This determines which register entries apply to your specific vehicle.</p>
                    </TooltipContent>
                  </Tooltip>
                </label>
                <div className="relative">
                  <select
                    value={yearFrom}
                    onChange={(e) => setYearFrom(e.target.value)}
                    className="w-full h-12 rounded-md border border-border/60 bg-secondary/30 px-4 text-base appearance-none"
                  >
                    <option value="">Any year</option>
                    {years.map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                </div>
              </div>

              {/* Vehicle Type Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                  Vehicle Type
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-3.5 h-3.5 text-muted-foreground/60" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p>Filter by the type of vehicle. This corresponds to the Australian Design Rules (ADR) vehicle category.</p>
                    </TooltipContent>
                  </Tooltip>
                </label>
                <div className="relative">
                  <select
                    value={vehicleType}
                    onChange={(e) => setVehicleType(e.target.value)}
                    className="w-full h-12 rounded-md border border-border/60 bg-secondary/30 px-4 text-base appearance-none"
                  >
                    <option value="">All types</option>
                    <option value="MA">Passenger Vehicle</option>
                    <option value="MB">Forward-Control Passenger (Vans)</option>
                    <option value="MC">Off-Road / 4WD</option>
                    <option value="MD">Light Bus</option>
                    <option value="NA">Light Commercial / Ute</option>
                    <option value="NB">Medium Truck</option>
                    <option value="LC">Motorcycle</option>
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                </div>
              </div>

              {/* Search Button */}
              <Button
                onClick={handleSearch}
                disabled={!selectedMake}
                className="w-full h-12 text-base font-semibold mt-2 bg-primary text-primary-foreground hover:bg-primary/90"
                size="lg"
              >
                Check Eligibility
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </TabsContent>

            <TabsContent value="chassis" className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                  Chassis Code or VIN
                  <Tooltip>
                    <TooltipTrigger>
                      <HelpCircle className="w-3.5 h-3.5 text-muted-foreground/60" />
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p>The chassis code (also called model code) is a short alphanumeric identifier for your vehicle type, such as JZX100 or GRS204. You can find it on the vehicle's registration plate or import documentation.</p>
                    </TooltipContent>
                  </Tooltip>
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Enter chassis code (e.g. JZX100, GRS204)..."
                    value={chassisQuery}
                    onChange={(e) => setChassisQuery(e.target.value.toUpperCase())}
                    onKeyDown={(e) => e.key === "Enter" && handleChassisSearch()}
                    className="pl-10 h-12 bg-secondary/30 border-border/60 text-base uppercase"
                  />
                </div>
              </div>

              <Button
                onClick={handleChassisSearch}
                disabled={!chassisQuery.trim()}
                className="w-full h-12 text-base font-semibold mt-2 bg-primary text-primary-foreground hover:bg-primary/90"
                size="lg"
              >
                Search by Chassis
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </TabsContent>
          </Tabs>
        </div>

        {/* Stats */}
        {stats && (
          <div className="mt-8 grid grid-cols-3 gap-4 text-center">
            <div className="bg-card/50 border border-border/30 rounded-lg p-4">
              <div className="text-2xl font-semibold text-primary">{stats.mreCount.toLocaleString()}</div>
              <div className="text-xs text-muted-foreground mt-1">
                Compliance Approvals
                <Tooltip>
                  <TooltipTrigger>
                    <HelpCircle className="w-3 h-3 inline ml-1 text-muted-foreground/50" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p>MRE (Model Report Eligibility) entries represent approved compliance workshops that can import and certify specific vehicle models.</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
            <div className="bg-card/50 border border-border/30 rounded-lg p-4">
              <div className="text-2xl font-semibold text-primary">{stats.sevCount.toLocaleString()}</div>
              <div className="text-xs text-muted-foreground mt-1">
                Eligible Vehicles
                <Tooltip>
                  <TooltipTrigger>
                    <HelpCircle className="w-3 h-3 inline ml-1 text-muted-foreground/50" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p>SEV (Specialist and Enthusiast Vehicle) entries are government-approved vehicle categories eligible for import into Australia.</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </div>
            <div className="bg-card/50 border border-border/30 rounded-lg p-4">
              <div className="text-2xl font-semibold text-primary">{stats.totalMakes}</div>
              <div className="text-xs text-muted-foreground mt-1">Vehicle Makes</div>
            </div>
          </div>
        )}

        {/* Info Section */}
        <div className="mt-12 mb-8 space-y-6">
          <div className="bg-card/30 border border-border/30 rounded-lg p-5">
            <h3 className="text-sm font-semibold text-foreground mb-2">How does this work?</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              This tool searches the Australian Government's ROVER register — the official database that determines
              which vehicles can be legally imported into Australia. If a vehicle appears on the register, it means
              there is an approved pathway to bring it into the country through a licensed compliance workshop.
            </p>
          </div>
          <div className="bg-card/30 border border-border/30 rounded-lg p-5">
            <h3 className="text-sm font-semibold text-foreground mb-2">What are SEVS and MRE?</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              <strong className="text-foreground">SEVS</strong> (Specialist and Enthusiast Vehicle Scheme) is the government register
              that makes a vehicle category eligible for import. <strong className="text-foreground">MRE</strong> (Model Report Eligibility)
              entries represent specific compliance workshops that have been approved to import and certify a particular vehicle model.
              Together, they define what can be imported and who can do it.
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
}
