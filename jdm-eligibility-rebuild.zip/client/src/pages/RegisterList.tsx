import { useLocation, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import Layout from "@/components/Layout";
import {
  CheckCircle2,
  XCircle,
  ArrowRight,
  Loader2,
  ExternalLink,
  HelpCircle,
  ShieldCheck,
  FileText,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const QUOTE_URL = "https://jdmconnect.com.au/get-a-quote/";

export default function RegisterList() {
  const [, navigate] = useLocation();
  const params = useParams<{ make: string; model: string }>();
  const make = decodeURIComponent(params.make || "");
  const model = decodeURIComponent(params.model || "");

  const { data: entries, isLoading } = trpc.vehicle.registerEntries.useQuery(
    { make, model },
    { enabled: !!make && !!model }
  );

  const breadcrumbs = [
    { label: "Search", href: "/" },
    { label: `${make}`, href: `/search?make=${encodeURIComponent(make)}` },
    { label: model },
  ];

  const mreEntries = entries?.filter((e) => e.type === "MRE") || [];
  const sevEntries = entries?.filter((e) => e.type === "SEV") || [];

  return (
    <Layout breadcrumbs={breadcrumbs} step={2}>
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          {entries && entries.length > 0 && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Eligible for Import
            </span>
          )}
        </div>
        <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-foreground">
          {make} {model}
        </h1>
        <p className="text-sm text-muted-foreground mt-2">
          {entries
            ? `${entries.length} register ${entries.length !== 1 ? "entries" : "entry"} found — select one to view full details.`
            : "Loading register entries..."}
        </p>
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <span className="ml-3 text-muted-foreground">Loading register entries...</span>
        </div>
      )}

      {/* Explainer */}
      {!isLoading && entries && entries.length > 0 && (
        <div className="bg-primary/5 border border-primary/15 rounded-lg p-4 mb-6">
          <div className="flex items-start gap-3">
            <HelpCircle className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            <div className="text-sm text-muted-foreground leading-relaxed">
              <p>
                <strong className="text-foreground">What am I looking at?</strong> Each card below represents
                a separate register entry for the {make} {model}. Different entries cover different build date ranges,
                chassis codes, or compliance pathways. Click on the entry that matches your vehicle to see full details.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SEV Entries */}
      {sevEntries.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <ShieldCheck className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-foreground">
              Vehicle Eligibility (SEVS)
            </h2>
            <Tooltip>
              <TooltipTrigger>
                <HelpCircle className="w-4 h-4 text-muted-foreground/60" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>SEVS (Specialist and Enthusiast Vehicle Scheme) entries confirm that this vehicle category is eligible for import into Australia. Each entry covers a specific build date range and chassis type.</p>
              </TooltipContent>
            </Tooltip>
          </div>
          <div className="space-y-3">
            {sevEntries.map((entry) => (
              <button
                key={entry.id}
                onClick={() => navigate(`/detail/${encodeURIComponent(entry.code)}`)}
                className="w-full text-left bg-card border border-border/60 rounded-xl p-5 sm:p-6 hover:border-primary/40 transition-all group"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/20">
                        SEV
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold ${
                          entry.statusLabel === "Active"
                            ? "bg-emerald-500/15 text-emerald-400"
                            : "bg-amber-500/15 text-amber-400"
                        }`}
                      >
                        {entry.statusLabel}
                      </span>
                      {entry.underReview && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/15 text-amber-400">
                          <AlertTriangle className="w-3 h-3" />
                          Under Review
                        </span>
                      )}
                    </div>
                    <h3 className="text-base font-semibold text-foreground group-hover:text-primary transition-colors">
                      {entry.label}
                    </h3>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-sm text-muted-foreground">
                      <span>Build: {entry.buildDateRange}</span>
                      {entry.category && <span>Category: {entry.category}</span>}
                      <span className="font-mono text-xs">#{entry.code}</span>
                    </div>
                    {entry.chassisCodes.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {entry.chassisCodes.map((code) => (
                          <span key={code} className="text-xs px-2 py-0.5 rounded bg-secondary/60 text-muted-foreground font-mono">
                            {code}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors shrink-0 mt-1" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* MRE Entries */}
      {mreEntries.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <FileText className="w-5 h-5 text-primary" />
            <h2 className="text-lg font-semibold text-foreground">
              Compliance Workshops (MRE)
            </h2>
            <Tooltip>
              <TooltipTrigger>
                <HelpCircle className="w-4 h-4 text-muted-foreground/60" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>MRE (Model Report Eligibility) entries represent approved compliance workshops that can import and certify this vehicle. Each workshop has been approved by the government to handle specific models and build dates.</p>
              </TooltipContent>
            </Tooltip>
          </div>
          <div className="space-y-3">
            {mreEntries.map((entry) => (
              <button
                key={entry.id}
                onClick={() => navigate(`/detail/${encodeURIComponent(entry.code)}`)}
                className="w-full text-left bg-card border border-border/60 rounded-xl p-5 sm:p-6 hover:border-primary/40 transition-all group"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-primary/15 text-primary border border-primary/20">
                        MRE
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold ${
                          entry.statusLabel === "Active"
                            ? "bg-emerald-500/15 text-emerald-400"
                            : entry.statusLabel === "Expired"
                              ? "bg-red-500/15 text-red-400"
                              : "bg-amber-500/15 text-amber-400"
                        }`}
                      >
                        {entry.statusLabel}
                      </span>
                    </div>
                    <h3 className="text-base font-semibold text-foreground group-hover:text-primary transition-colors">
                      {entry.workshopName || entry.label}
                    </h3>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-sm text-muted-foreground">
                      <span>Build: {entry.buildDateRange}</span>
                      {entry.complianceLevel && <span>Level: {entry.complianceLevel}</span>}
                      <span className="font-mono text-xs">#{entry.code}</span>
                    </div>
                  </div>
                  <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors shrink-0 mt-1" />
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* No entries */}
      {!isLoading && entries && entries.length === 0 && (
        <div className="text-center py-16">
          <XCircle className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No register entries found</h3>
          <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
            This vehicle does not appear to have any current register entries. Contact JDM Connect for more information.
          </p>
          <a href={QUOTE_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-1 rounded-md bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:bg-primary/90 transition-colors">
              Contact JDM Connect
              <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      )}

      {/* CTA */}
      {!isLoading && entries && entries.length > 0 && (
        <div className="mt-8 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-xl p-6 text-center">
          <h3 className="text-lg font-semibold text-foreground mb-2">Ready to import this vehicle?</h3>
          <p className="text-sm text-muted-foreground mb-4 max-w-md mx-auto">
            JDM Connect can handle the entire import process for you — from sourcing in Japan to delivery at your door.
          </p>
          <a href={QUOTE_URL} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 rounded-md bg-primary text-primary-foreground px-6 py-3 text-sm font-semibold hover:bg-primary/90 transition-colors">
              Get a Free Quote
              <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      )}
    </Layout>
  );
}
