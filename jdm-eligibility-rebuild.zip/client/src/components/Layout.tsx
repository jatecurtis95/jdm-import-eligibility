import { Link, useLocation } from "wouter";
import { ChevronRight, Search, List, FileText, ClipboardCheck } from "lucide-react";

const LOGO_URL = "/manus-storage/Lockup_White@4x_8eb1c658.png";
const QUOTE_URL = "https://jdmconnect.com.au/get-a-quote/";

interface BreadcrumbItem {
  label: string;
  href?: string;
}

const STEPS = [
  { label: "Search", icon: Search },
  { label: "Results", icon: List },
  { label: "Register", icon: FileText },
  { label: "Details", icon: ClipboardCheck },
];

function StepIndicator({ currentStep }: { currentStep: number }) {
  return (
    <div className="flex items-center gap-1 mb-6 overflow-x-auto">
      {STEPS.map((step, i) => {
        const Icon = step.icon;
        const isActive = i === currentStep;
        const isCompleted = i < currentStep;
        return (
          <div key={step.label} className="flex items-center">
            {i > 0 && (
              <div
                className={`w-6 sm:w-10 h-px mx-1 ${
                  isCompleted ? "bg-primary" : "bg-border/50"
                }`}
              />
            )}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                isActive
                  ? "bg-primary/15 text-primary border border-primary/30"
                  : isCompleted
                    ? "text-primary/70"
                    : "text-muted-foreground/50"
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{step.label}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Breadcrumbs({ items }: { items: BreadcrumbItem[] }) {
  if (items.length <= 1) return null;
  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-sm text-muted-foreground mb-2 flex-wrap">
      {items.map((item, i) => (
        <span key={i} className="flex items-center gap-1.5">
          {i > 0 && <ChevronRight className="w-3.5 h-3.5 shrink-0" />}
          {item.href ? (
            <Link href={item.href} className="hover:text-primary transition-colors">
              {item.label}
            </Link>
          ) : (
            <span className="text-foreground font-medium">{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

interface LayoutProps {
  children: React.ReactNode;
  breadcrumbs?: BreadcrumbItem[];
  step?: number; // 0=Search, 1=Results, 2=Register, 3=Details
}

export default function Layout({ children, breadcrumbs, step }: LayoutProps) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-3 shrink-0">
            <img src={LOGO_URL} alt="JDM Connect" className="h-8 sm:h-9" />
          </Link>
          <nav className="flex items-center gap-4">
            <Link
              href="/"
              className={`text-sm font-medium transition-colors hidden sm:block ${
                location === "/" ? "text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Eligibility Checker
            </Link>
            <a
              href="https://jdmconnect.com.au/landed-cost-calculator/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors hidden sm:block"
            >
              Landed Cost
            </a>
            <a
              href={QUOTE_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center rounded-md text-sm font-semibold h-9 px-4 bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              Get a Quote
            </a>
          </nav>
        </div>
      </header>

      {/* Main */}
      <main className="flex-1">
        <div className="container py-6 sm:py-8">
          {step !== undefined && step > 0 && <StepIndicator currentStep={step} />}
          {breadcrumbs && <Breadcrumbs items={breadcrumbs} />}
          {children}
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-card/50">
        <div className="container py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img src={LOGO_URL} alt="JDM Connect" className="h-6 opacity-60" />
            </div>
            <div className="text-xs text-muted-foreground text-center sm:text-right leading-relaxed">
              <p>Data sourced from the Australian Government ROVER register.</p>
              <p className="mt-1">
                This tool is for guidance only — always verify eligibility with a licensed compliance workshop.
              </p>
            </div>
          </div>
          <div className="mt-6 pt-4 border-t border-border/30 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-4">
              <a href="https://jdmconnect.com.au" target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
                jdmconnect.com.au
              </a>
              <a href="mailto:info@jdmconnect.com.au" className="hover:text-primary transition-colors">
                info@jdmconnect.com.au
              </a>
            </div>
            <p>&copy; {new Date().getFullYear()} JDM Connect Pty Ltd. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export { Breadcrumbs };
export type { BreadcrumbItem };
