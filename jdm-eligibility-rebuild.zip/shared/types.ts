/**
 * Unified type exports
 * Import shared types from this single entry point.
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

// Raw data shapes from data.json
export interface RawMRE {
  "Approval number": string;
  Make: string;
  Model: string;
  "Approval status": string;
  "Model report type": string;
  "Post-modification category": string;
  "Compliance Level": string;
  "Build date range": string;
  _detail_url: string;
  _approval_holder?: string;
  _workshop_short?: string;
}

export interface RawSEV {
  "SEV #": string;
  Make: string;
  Model: string;
  Category: string;
  "Model code": string;
  "Build date from": string;
  "Build date to": string;
  Expiry: string;
  "Under review": string;
  _detail_url: string;
  _sev_category?: string;
  _sev_category_raw?: string;
}

export interface RawData {
  fetched_at: string;
  mre: RawMRE[];
  sev: RawSEV[];
}

export interface VehicleSearchResult {
  id: string;
  make: string;
  model: string;
  eligible: boolean;
  buildDateRange: string;
  buildYearStart: number | null;
  buildYearEnd: number | null;
  mreCount: number;
  sevCount: number;
  chassisCodes: string[];
  propulsion: string[];
}

export interface RegisterEntry {
  id: string;
  type: "MRE" | "SEV";
  code: string;
  label: string;
  status: string;
  statusLabel: string;
  make: string;
  model: string;
  buildDateRange: string;
  chassisCodes: string[];
  category?: string;
  complianceLevel?: string;
  workshopName?: string;
  expiry?: string;
  underReview?: boolean;
  detailUrl: string;
}

export interface VehicleDetail extends RegisterEntry {
  modelReportType?: string;
  postModCategory?: string;
  sevCategory?: string;
}

export interface MakeSuggestion {
  make: string;
  count: number;
}

export interface ModelSuggestion {
  model: string;
  make: string;
  count: number;
}
